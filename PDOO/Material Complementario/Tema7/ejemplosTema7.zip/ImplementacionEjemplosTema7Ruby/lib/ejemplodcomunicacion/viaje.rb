class Viaje
  def initialize
    
  end
  
  def setPasajero(p)
     # pendiente de conocer c�mo implementar
  end
end
