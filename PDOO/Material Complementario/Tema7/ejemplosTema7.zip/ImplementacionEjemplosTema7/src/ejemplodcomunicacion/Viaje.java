
package ejemplodcomunicacion;


class Viaje {
    
    Viaje(Pasaporte p, Asiento s){//pendiente de conocer c�mo implementar
    }
    
    public void setPasajero(Pasajero p){//pendiente de conocer c�mo implementar  
    }
    
}
