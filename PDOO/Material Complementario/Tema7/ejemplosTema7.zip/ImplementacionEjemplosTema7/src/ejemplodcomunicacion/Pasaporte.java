
package ejemplodcomunicacion;

class Pasaporte {
    
}
