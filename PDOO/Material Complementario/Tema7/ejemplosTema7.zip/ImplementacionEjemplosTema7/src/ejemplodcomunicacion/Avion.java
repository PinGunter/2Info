
package ejemplodcomunicacion;


class Avion {
    
    public Asiento eligeAsientoLibre(){
    
    }
    
}
