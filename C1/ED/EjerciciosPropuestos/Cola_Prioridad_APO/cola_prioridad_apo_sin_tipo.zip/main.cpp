#include <iostream>
#include "ColaPrioridad.h"

ostream & operator<<(ostream &os, const ColaPrioridad<char>::tipo &t){
    os << "Elemento: " << t.get_elemento() << " Prioridad: " << t.get_prioridad() << endl;
    return os;
}

int main() {
    srand(time(NULL));
    ColaPrioridad<char> cola;
    char base = 'a';


    cout << "Insertando datos" << endl;
    for (int i=0; i < 10; i++){
        //typename ColaPrioridad<char>::tipo nuevo(rand() % 26 + base,i) ;
        char nuevo = rand() % 26 + base;
        cout << nuevo << endl;
        cola.poner(nuevo);
    }
    cout << "Leyendo datos" << endl;
    for (int i=0; i< 10; i++){
        cout << cola.frente();
        cola.quitar();
    }

    return 0;
}
